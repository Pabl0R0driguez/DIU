import axios from "axios";

export default axios.create({
  baseURL: "http://proyectodiuprs-env.eba-xgtf4utg.us-east-1.elasticbeanstalk.com:8098/api/v1/tutorials",
  headers: {
    "Content-type": "application/json"
  }
}); 
