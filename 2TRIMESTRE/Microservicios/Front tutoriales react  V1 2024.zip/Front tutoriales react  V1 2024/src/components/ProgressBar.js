import React from 'react'
import "boostrap/dis/css/boostrap.min.css"

function ProgressBar(props) {
  return (
    <div className='contendorBarraProgreso'>
      <span className='progressText'{"Procesando archivos"}>

      </span>
    </div>
  )
}

export default ProgressBar