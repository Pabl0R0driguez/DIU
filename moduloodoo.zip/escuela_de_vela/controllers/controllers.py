# -*- coding: utf-8 -*-
# from odoo import http


# class EscuelaDeVela(http.Controller):
#     @http.route('/escuela_de_vela/escuela_de_vela', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/escuela_de_vela/escuela_de_vela/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('escuela_de_vela.listing', {
#             'root': '/escuela_de_vela/escuela_de_vela',
#             'objects': http.request.env['escuela_de_vela.escuela_de_vela'].search([]),
#         })

#     @http.route('/escuela_de_vela/escuela_de_vela/objects/<model("escuela_de_vela.escuela_de_vela"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('escuela_de_vela.object', {
#             'object': obj
#         })

