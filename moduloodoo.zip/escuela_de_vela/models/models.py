# -*- coding: utf-8 -*-

from odoo import models, fields, api



class Escuela(models.Model):
    _name = 'escuela.vela'
    _description = 'Escuela de Vela'

    name = fields.Char(string="Nombre de la Escuela", required=True)
    logo = fields.Binary(string="Logotipo")
    telefono = fields.Char(string="Teléfono")
    email = fields.Char(string="Correo Electrónico")
    direccion = fields.Text(string="Dirección")
    
    def print_report_escuela(self):
        return self.env.ref('escuela_de_vela.action_report_escuela').report_action(self)



class Curso(models.Model):
    _name = 'escuela.curso'
    _description = 'Curso de Vela'
    _order = 'name'

    name = fields.Char(string="Título del Curso", required=True)
    duracion_dias = fields.Integer(string="Duración (días)")
    horas = fields.Integer(string="Horas Totales")
    precio = fields.Float(string="Precio (€)")
    escuela_id = fields.Many2one('escuela.vela', string="Escuela", ondelete='cascade')


class Monitor(models.Model):
    _name = 'escuela.monitor'
    _description = 'Monitor de Vela'
    _order = 'name'

    name = fields.Char(string="Nombre", required=True)
    telefono = fields.Char(string="Teléfono")
    email = fields.Char(string="Correo Electrónico")
    codigo = fields.Char(string="Código de Monitor", required=True)
    escuela_ids = fields.Many2many('escuela.vela', string="Escuelas con las que colabora")

    # Restricción para asegurar unicidad del código
    _sql_constraints = [
        ('unique_codigo_monitor', 'UNIQUE(codigo)', 'El código del monitor debe ser único.')
    ]


class Alumno(models.Model):
    _name = 'escuela.alumno'
    _description = 'Alumno de la Escuela de Vela'
    _order = 'name'

    name = fields.Char(string="Nombre del Alumno", required=True)
    telefono = fields.Char(string="Teléfono")
    email = fields.Char(string="Correo Electrónico")
    matricula = fields.Char(string="Número de Matrícula", required=True)
    escuela_id = fields.Many2one('escuela.vela', string="Escuela", ondelete='cascade')
    curso_ids = fields.Many2many('escuela.curso', string="Cursos Inscritos")
    # Restricción para que la matrícula sea única por escuela
    _sql_constraints = [
        ('unique_matricula_escuela', 'UNIQUE(matricula, escuela_id)', 'La matrícula debe ser única por escuela.')
    ]
